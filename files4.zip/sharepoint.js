/* =========================================================================
   CONECTOR SHAREPOINT — Comercial Express
   -------------------------------------------------------------------------
   REQUISITO CLAVE: este panel debe abrirse DESDE DENTRO de tu sitio
   SharePoint (subido a una biblioteca de documentos y abierto con esa URL,
   o embebido en una página del sitio). Si lo abres como archivo local
   (file://) o desde un dominio externo, la API REST de SharePoint va a
   rechazar las peticiones — no es un bug de este panel, es la sesión de
   autenticación de Microsoft, que solo viaja dentro del mismo sitio.

   Qué hace: usa la API REST nativa de SharePoint (_api/web/...), que se
   autentica sola con la sesión de tu correo institucional (no requiere
   registrar una app en Azure AD ni pedir tokens). Solo LEE datos — no
   escribe nada de vuelta a las listas (fase 1: sincronización visual).

   CÓMO CONFIGURAR:
     1. Completa SHAREPOINT_CONFIG.siteUrl con la URL de tu sitio
        (sin barra al final), ej: 'https://tuempresa.sharepoint.com/sites/CEX'
     2. Completa el nombre EXACTO (Título) de cada lista tal como aparece
        en SharePoint.
     3. Si vas a leer el archivo de Bsale directo desde una biblioteca de
        documentos (en vez de subirlo a mano), completa
        archivoVentasServerRelativeUrl con la ruta relativa del archivo
        (clic derecho en el archivo en SharePoint > Detalles > te muestra
        la ruta, o cópiala de la URL quitando "https://tuempresa.sharepoint.com").
     4. Usa el botón "Diagnosticar conexión" en el panel — te va a listar
        las columnas reales de cada lista para que ajustes MAPEO_CAMPOS
        si no calzan con los nombres de acá abajo.
   ========================================================================= */

const SHAREPOINT_CONFIG = {
  siteUrl: '', // <-- COMPLETAR. Ej: 'https://tuempresa.sharepoint.com/sites/ComercialExpress'
  listas: {
    sucursales: 'Sucursales',
    dotacion: 'Dotación Vigente',
    indicadores: 'Indicadores',
    metas: 'Metas y Cuotas',
  },
  archivoVentasServerRelativeUrl: '', // opcional, ver instrucciones arriba
};

// Nombres INTERNOS de columna esperados en cada lista (SharePoint suele
// usar el nombre interno distinto al que ves en pantalla si tiene espacios
// o tildes — verifícalo con "Diagnosticar conexión"). Ajusta acá si no calza.
const MAPEO_CAMPOS = {
  sucursales: { nombreBsale: 'Title', ciudad: 'Ciudad', tipo: 'Tipo', activa: 'Activa', orden: 'Orden' },
  dotacion: { nombre: 'Title', sucursal: 'Sucursal', activo: 'Activo' },
  indicadores: { key: 'Title', activo: 'Activo', label: 'Nombre', corto: 'Corto', orden: 'Orden' },
  metas: { key: 'IndicadorKey', meta: 'MetaMensual', cuotaDia: 'CuotaDia' },
};

let SP_STATUS = {
  sucursales: null, dotacion: null, indicadores: null, metas: null, archivo: null,
};

function spConfigured() {
  return !!SHAREPOINT_CONFIG.siteUrl;
}

async function spFetchListItems(listTitle) {
  const url = `${SHAREPOINT_CONFIG.siteUrl}/_api/web/lists/getbytitle('${encodeURIComponent(listTitle)}')/items?$top=5000`;
  const resp = await fetch(url, {
    headers: { Accept: 'application/json;odata=nometadata' },
    credentials: 'same-origin',
  });
  if (!resp.ok) throw new Error(`Lista "${listTitle}": HTTP ${resp.status} (¿nombre correcto? ¿tienes permiso de lectura?)`);
  const json = await resp.json();
  return json.value || [];
}

async function spFetchListFields(listTitle) {
  const url = `${SHAREPOINT_CONFIG.siteUrl}/_api/web/lists/getbytitle('${encodeURIComponent(listTitle)}')/fields?$select=Title,InternalName,Hidden&$filter=Hidden eq false`;
  const resp = await fetch(url, { headers: { Accept: 'application/json;odata=nometadata' }, credentials: 'same-origin' });
  if (!resp.ok) throw new Error(`No se pudo leer columnas de "${listTitle}": HTTP ${resp.status}`);
  const json = await resp.json();
  return (json.value || []).map(f => ({ titulo: f.Title, interno: f.InternalName }));
}

async function spFetchFileBytes(serverRelativeUrl) {
  const url = `${SHAREPOINT_CONFIG.siteUrl.replace(/\/sites\/[^/]+.*/, '')}_api/web/GetFileByServerRelativeUrl('${encodeURIComponent(serverRelativeUrl)}')/$value`;
  const resp = await fetch(url, { credentials: 'same-origin' });
  if (!resp.ok) throw new Error(`Archivo Bsale: HTTP ${resp.status} (¿ruta correcta?)`);
  const modified = resp.headers.get('Last-Modified');
  const buf = await resp.arrayBuffer();
  return { buf, modified };
}

/* ---------------------------- diagnóstico ---------------------------- */
// Prueba la conexión a cada lista configurada y devuelve, por lista, si
// respondió y qué columnas tiene disponibles — para ajustar MAPEO_CAMPOS
// sin tener que adivinar.
async function spDiagnostico() {
  if (!spConfigured()) {
    return { ok: false, mensaje: 'Falta completar SHAREPOINT_CONFIG.siteUrl en sharepoint.js.' };
  }
  const resultado = {};
  for (const [clave, listTitle] of Object.entries(SHAREPOINT_CONFIG.listas)) {
    try {
      const campos = await spFetchListFields(listTitle);
      resultado[clave] = { ok: true, lista: listTitle, columnas: campos };
    } catch (err) {
      resultado[clave] = { ok: false, lista: listTitle, error: err.message };
    }
  }
  return { ok: true, listas: resultado };
}

/* ---------------------------- sincronización ---------------------------- */

function leerCampo(item, mapeo, campo, fallback) {
  const v = item[mapeo[campo]];
  return v !== undefined && v !== null ? v : fallback;
}

async function spSincronizarSucursales() {
  const items = await spFetchListItems(SHAREPOINT_CONFIG.listas.sucursales);
  const m = MAPEO_CAMPOS.sucursales;
  const nuevas = items
    .map(it => ({
      nombreBsale: leerCampo(it, m, 'nombreBsale', ''),
      nombreVisible: leerCampo(it, m, 'nombreBsale', ''),
      ciudad: leerCampo(it, m, 'ciudad', 'Sin ciudad'),
      tipo: leerCampo(it, m, 'tipo', ''),
      activa: !!leerCampo(it, m, 'activa', true),
      orden: Number(leerCampo(it, m, 'orden', 999)),
    }))
    .filter(s => s.nombreBsale)
    .sort((a, b) => a.orden - b.orden);
  if (nuevas.length) {
    SUCURSALES.length = 0;
    nuevas.forEach(s => SUCURSALES.push(s));
  }
  SP_STATUS.sucursales = new Date();
  return nuevas.length;
}

async function spSincronizarDotacion() {
  const items = await spFetchListItems(SHAREPOINT_CONFIG.listas.dotacion);
  const m = MAPEO_CAMPOS.dotacion;
  DOTACION_VIGENTE.length = 0;
  items.forEach(it => {
    const activo = leerCampo(it, m, 'activo', true);
    if (!activo) return;
    DOTACION_VIGENTE.push({
      nombre: leerCampo(it, m, 'nombre', ''),
      sucursal: leerCampo(it, m, 'sucursal', ''),
    });
  });
  SP_STATUS.dotacion = new Date();
  return DOTACION_VIGENTE.length;
}

async function spSincronizarIndicadores() {
  const items = await spFetchListItems(SHAREPOINT_CONFIG.listas.indicadores);
  const m = MAPEO_CAMPOS.indicadores;
  // La LISTA solo controla visibilidad/orden/etiquetas de indicadores que
  // YA existen en indicadores.js (la regla de cálculo sigue siendo código:
  // qué filas de Bsale cuentan para cada uno es lógica de negocio, no un
  // dato de lista). Esto evita que un cambio accidental en SharePoint
  // rompa cómo se calculan los números.
  let actualizados = 0;
  items.forEach(it => {
    const key = leerCampo(it, m, 'key', null);
    if (!key) return;
    const ind = INDICADORES.find(i => i.key === key);
    if (!ind) return;
    ind.activo = !!leerCampo(it, m, 'activo', ind.activo);
    ind.orden = Number(leerCampo(it, m, 'orden', ind.orden));
    const corto = leerCampo(it, m, 'corto', null);
    if (corto) ind.corto = corto;
    actualizados++;
  });
  SP_STATUS.indicadores = new Date();
  return actualizados;
}

async function spSincronizarMetas() {
  const items = await spFetchListItems(SHAREPOINT_CONFIG.listas.metas);
  const m = MAPEO_CAMPOS.metas;
  let actualizados = 0;
  items.forEach(it => {
    const key = leerCampo(it, m, 'key', null);
    if (!key) return;
    METAS[key] = {
      meta: Number(leerCampo(it, m, 'meta', 0)) || 0,
      cuotaDia: Number(leerCampo(it, m, 'cuotaDia', 0)) || 0,
    };
    actualizados++;
  });
  saveMetas();
  SP_STATUS.metas = new Date();
  return actualizados;
}

async function spSincronizarArchivoVentas() {
  if (!SHAREPOINT_CONFIG.archivoVentasServerRelativeUrl) return 0;
  const { buf, modified } = await spFetchFileBytes(SHAREPOINT_CONFIG.archivoVentasServerRelativeUrl);
  const wb = XLSX.read(buf, { type: 'array', cellDates: false });
  ROWS = parseArchivoPlano(wb);
  fileName = 'SharePoint: ' + SHAREPOINT_CONFIG.archivoVentasServerRelativeUrl.split('/').pop();
  SP_STATUS.archivo = modified ? new Date(modified) : new Date();
  return ROWS.length;
}

// Orquesta la sincronización completa. Cada paso es independiente — si uno
// falla (ej. no configuraste esa lista todavía) los demás igual se intentan.
async function spSincronizarTodo(onProgress) {
  const pasos = [
    ['Sucursales', spSincronizarSucursales],
    ['Dotación', spSincronizarDotacion],
    ['Indicadores', spSincronizarIndicadores],
    ['Metas', spSincronizarMetas],
    ['Archivo de ventas', spSincronizarArchivoVentas],
  ];
  const resultados = [];
  for (const [nombre, fn] of pasos) {
    try {
      const n = await fn();
      resultados.push({ nombre, ok: true, detalle: `${n} registro(s)` });
    } catch (err) {
      resultados.push({ nombre, ok: false, detalle: err.message });
    }
    if (onProgress) onProgress(resultados.slice());
  }
  return resultados;
}
